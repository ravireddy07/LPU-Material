#Question_2

#Day = c('D1','D2','D3','D4','D5','D6','D7','D8','D9','D10','D11','D12','D13','D14')
#Outlook = c('Sunny','Sunny','Overcast','Rain','Rain','Rain','Overcast','Sunny','Sunny','Rain','Sunny','Overcast','Overcast','Rain')
#Temp = c('Hot','Hot','Hot','Mild','Cool','Cool','Cool','Mild','Cool','Mild','Mild','Mild','Hot','Mild')
#Hum = c('High','High','High','High','Normal','Normal','Normal','High','Normal','Normal','Normal','High','Normal','High')
#Wind = c('Weak','Strong','Weak','Weak','Weak','Strong','Strong','Weak','Weak','Weak','Strong','Strong','Weak','Strong')
#PlayTennis = c('No','No','Yes','Yes','Yes','No','Yes','No','Yes','Yes','Yes','Yes','Yes','No')

#Tennis = data.frame(Day,Outlook,Temp,Hum,Wind,PlayTennis)
#Tennis

Tennis = read.csv(file.choose(), sep = ',')

View(Tennis)
Tennis = Tennis[-1]

set.seed(1234)
Index <- sample(2, nrow(Tennis), replace = T, prob = c(0.6, 0.4))
TRAINING<- Tennis[Index == 1,]
TESTING<- Tennis[Index == 2,]

summary(TRAINING)
summary(TESTING)

Model_2 = rpart(PlayTennis~., data=TRAINING, method = "class")

rpart.plot(Model_2)
rpart.plot(Model_2,type=4, extra=101)

PredictValue=predict(Model_2, TESTING, type="class")


(VALIDATION=table(TEST=TESTING$PlayTennis,PREDICTED=PredictValue))


(ACCURACY=sum(diag(VALIDATION))/sum(VALIDATION)*100)

newdata = data.frame(Outlook = 'Sunny', Temperature = 'Hot', Humidity = 'High', Wind = 'Weak')

Final_output = predict(Model_2, newdata)
Final_output