install.packages('missForest')
library(missForest)


#Question_1

#Creating given Dataset
id = c(1:11)
height = c(5,5.11,5.6,5.9,4.8,5.8,5.3,5.8,5.5,5.6,5.5)
age = c(45,26,30,34,40,36,19,28,23,32,38)
weight = c(77,78,55,88,50,78,40,70,45,58,0)

IndEmbassy = data.frame(id,height,age,weight)
IndEmbassy

View(IndEmbassy)
summary(IndEmbassy)

Model_1 = lm(weight~age,IndEmbassy)
summary(Model_1)

plot(IndEmbassy$age,IndEmbassy$weight)

abline(Model_1, col='Red')

prediction = predict(Model_1,data.frame(height=5.5,age=38))
prediction

