
#---------------------------Q1----------------------------
install.packages("missForest")
library(missForest)

#breastCan <- read.csv("Q.1 BREAST CANCER.csv")
breastCan <- read.csv(file.choose(),header=T)
summary(breastCan)

is.na(breastCan)

breastCan[!complete.cases(breastCan),]



breastCan$diagnosis[breastCan$diagnosis == 'M'] <- 'YES'
breastCan$diagnosis[breastCan$admit == 'B'] <- 'NO'
breastCan$diagnosis=factor(breastCan$diagnosis)
breastCan$id<- factor(breastCan$id)

datacleaned=breastCan
summary(datacleaned)


dataMF <- missForest(datacleaned)
datanona = as.data.frame(dataMF[[1]])


#-------------------------Q2--------------------------------

install.packages("MASS");
library(MASS)
View(painters)

paintData = painters

summary(paintData)

paintCleaned = paintData


paintNormal = function(x){
  (x-min(x))/(max(x)-min(x))
}

paintDataNormal = as.data.frame(lapply(paintCleaned[1:4], paintNormal))
paintDataNormal

paintDataNormal = cbind(paintCleaned$School, paintDataNormal)
View(paintDataNormal)

paintDataNormal = paintDataNormal[,-2]

set.seed(12345)

Index <- sample(2, nrow(paintDataNormal), replace = T, prob = c(0.7, 0.3))

paintTrain = paintDataNormal[index == 1,]
paintTrain
paintTrainlabeling = paintTrain[,1]
paintTrain = paintTrain[,-1]
summary(paintTrain)


paintTest = paintDataNormal[index == 2,]
paintTest
paintTestlabeling = paintTest[,1]
paintTest = paintTest[,-1]
summary(paintTest)



(num = round(sqrt(nrow(pdata_norm))))

for(i in 1:num) {
  paintPredction = knn(train = paintTrain, test = paintTest, cl = paintTrainlabeling, k = i )
  paintValidation = table(paintTestlabeling, paintPredction)
  paintAccuracy = (sum(diag(paintValidation))/sum(paintValidation))
  print(paste("When k will be = ",i,", Then Accuracy would be = ", paintAccuracy))
}  



checkPaint = data.frame( Drawing = 13, Color = 9, Expression = 8)
summary(checkPaint)

paintTrain
paintTrainlabeling

checkingPainter = knn(train = paintTrain, test = checkPaint, cl = paintTrainlabeling, k = 8)

print(paste(" The School of new painter would be = ",checkingPainter))



#-------------------------Q3--------------------------------

#lungCap <- read.csv("Q.3 LUNGCAP.csv")
lungCap <- read.csv(file.choose(),header=T)
summary(lungCap)

is.na(lungCap)